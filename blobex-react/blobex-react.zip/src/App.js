import React from 'react';
import './App.css';
import BlobexList from './BlobexList'
import data from './blobex.json'

export default function App() {
  return (
    <div>
     <BlobexList/>
    </div>
  )
}

