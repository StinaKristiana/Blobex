import React, { Component } from 'react';
import data from './blobex.json';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Form, Col, Button, Row } from 'react-bootstrap';

console.log(data);

class BlobexList extends Component {
	render() {
		return (
			<div className="full-screen">
				<div className="form-container">
					{data.Widgets.map((widgets) => {
						return (
							<Form>
								<Row className="form-header" style={{ margin: 0 }}>
									<Button style={{ border: 0 }} variant="outline-danger" size="sm">
										Cancel
									</Button>
									<h1>{widgets.name}</h1>
									<Button style={{ border: 0 }} variant="outline-success" size="sm">
										Save
									</Button>
								</Row>
								<div>
									{widgets.items.map((details) => {
										return (
											<div>
												<Row style={{ margin: 0 }} className="form-sub-header">
													<h2>{details.header}</h2>
												</Row>
												{details.items.map((obj) => {
													return (
														<Col xs={12}>
															<Col xs={12 / details.columns}>
																<Form.Group controlId="formBasicEmail">
																	<Form.Label>{obj.label}</Form.Label>
																	<Form.Control
																		type={obj.type}																		placeholder="Enter email"
																	/>
																	<Form.Text className="text-muted">
																		We'll never share your email with anyone else.
																	</Form.Text>
																</Form.Group>
															</Col>
														</Col>
													);
												})}
											</div>
										);
									})}
								</div>
							</Form>
						);
					})}
				</div>
			</div>
		);
	}
}
export default BlobexList;
